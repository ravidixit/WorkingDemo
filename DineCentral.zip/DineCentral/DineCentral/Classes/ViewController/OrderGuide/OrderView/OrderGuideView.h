//
//  OrderGuideView.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderGuideView : UIView <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,weak) IBOutlet UITableView *orderItems;
@property (nonatomic,weak) IBOutlet UIView *tableHeader;

@end
