//
//  DatePickerContent.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "DatePickerContent.h"

@implementation DatePickerContent

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (IBAction)selectDateTime:(id)sender{
    if ([self.delegate respondsToSelector:@selector(didSelectContentData:)]) {
        [self.delegate didSelectContentData:self.dtPicker.date];
    }
}
- (IBAction)cancelPickerView:(id)sender{
    if ([self.delegate respondsToSelector:@selector(didCancelDateSelection)]) {
        [self.delegate didCancelDateSelection];
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
