//
//  DatePickerContent.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol  DatePickerContentDelegate <NSObject>

- (void)didSelectContentData:(id)data;
- (void)didCancelDateSelection;

@end


@interface DatePickerContent : UIView

@property (nonatomic,weak) IBOutlet UIDatePicker *dtPicker;
@property (nonatomic,weak) id delegate;

- (IBAction)selectDateTime:(id)sender;
- (IBAction)cancelPickerView:(id)sender;

@end
