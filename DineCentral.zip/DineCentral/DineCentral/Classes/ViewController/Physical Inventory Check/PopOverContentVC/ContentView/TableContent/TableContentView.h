//
//  TableContentView.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol  TableContentViewDelegate <NSObject>

- (void)didSelectContentData:(id)data;

@end



@interface TableContentView : UIView <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *accountsArray;
}

- (void)populateTableWithData:(id)data;

@property (nonatomic,weak) IBOutlet UITableView *tableContent;
@property (nonatomic,weak) id delegate;
@end
