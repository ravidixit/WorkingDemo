//
//  PopOverContentVC.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatePickerContent.h"
#import "TableContentView.h"

@protocol PopoverContentDelegate <NSObject>

- (void)didSelectData:(id)data;
- (void)dismissPopOverContentView;

@end

typedef NS_ENUM(NSInteger, ContentViewType) {
    PopOverContentViewTable,
    PopOverContentViewDatePicker
};


@interface PopOverContentVC : UIViewController


@property (nonatomic,weak) IBOutlet DatePickerContent *datePickerView;
@property (nonatomic,weak) IBOutlet TableContentView *tableViewContent;
@property (nonatomic,weak) id delegate;



- (void)displayPopOverContentWithData:(id)data forView:(ContentViewType)viewType;


@end
