//
//  PopOverContentVC.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "PopOverContentVC.h"

@interface PopOverContentVC () <DatePickerContentDelegate>

@end

@implementation PopOverContentVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)displayPopOverContentWithData:(id)data forView:(ContentViewType)viewType{
    if (data!=nil) {
        if (viewType==PopOverContentViewDatePicker) {
            [self.datePickerView setFrame:CGRectMake(0, 0, 400, 273)];
            [self.view addSubview:self.datePickerView];
            self.datePickerView.delegate = self;
        }else{
            [self.tableViewContent setFrame:self.view.frame];
            [self.view addSubview:self.tableViewContent];
            self.tableViewContent.delegate = self;
            [self.tableViewContent populateTableWithData:nil];
        }
    }
}


#pragma mark DatePickerContent view delegate
-(void)didSelectContentData:(id)data{
    if (data!=nil) {
            if ([self.delegate respondsToSelector:@selector(didSelectData:)]) {
                [self.delegate didSelectData:data];
            }
    }else{
        
    }
}

- (void)didCancelDateSelection{
    if ([self.delegate respondsToSelector:@selector(dismissPopOverContentView)]) {
        [self.delegate dismissPopOverContentView];
    }
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
