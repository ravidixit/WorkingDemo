//
//  TableViewCell.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell


@property (nonatomic,weak) IBOutlet UILabel *storageArea;
@property (nonatomic,weak) IBOutlet UILabel *counted;
@property (nonatomic,weak) IBOutlet UILabel *notCounted;
@property (nonatomic,weak) IBOutlet UILabel *status;
@property (nonatomic,weak) IBOutlet UIView *statusColorCode;

@end
