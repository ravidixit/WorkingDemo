//
//  PhysicalInventoryView.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Inventory.h"
#import "TableViewCell.h"

@interface PhysicalInventoryView : UIView <UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *inventoryItems;
}

@property (nonatomic,weak) IBOutlet UITableView *inventoryTable;
@property (nonatomic,weak) IBOutlet UIView *tableHeader;
@property (nonatomic,weak) IBOutlet UIView *tableFooter;
@property (nonatomic,strong) UIPopoverController *popOverController;

- (IBAction)displayPopOver:(id)sender;


@end
