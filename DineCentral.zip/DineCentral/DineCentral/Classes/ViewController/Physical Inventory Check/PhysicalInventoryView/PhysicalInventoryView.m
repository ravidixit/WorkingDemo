//
//  PhysicalInventoryView.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "PhysicalInventoryView.h"
#import "PopOverContentVC.h"
#import "DateTimeHelper.h"


@interface PhysicalInventoryView () <PopoverContentDelegate>
{
    UIView *selectedView;
}
- (void)displayPopOverinView:(UIView*)view withData:(id)data;

@end

@implementation PhysicalInventoryView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)displayPopOverinView:(UIView*)view withData:(id)data{
    
    PopOverContentVC *popOverContent = [[PopOverContentVC alloc]init];
    popOverContent.delegate = self;
    
    // The view with the dateTime has been given the tag as 1 so as to identify the contents of popOver
    if (view.tag==1) {
         [popOverContent displayPopOverContentWithData:@"Ravi Dixit" forView:PopOverContentViewDatePicker];
    }else{
         [popOverContent displayPopOverContentWithData:@"Ravi Dixit" forView:PopOverContentViewTable];
    }

    selectedView = view; // a global variable to track down the views which display popOver
    self.popOverController = [[UIPopoverController alloc]initWithContentViewController:popOverContent];

    [self dismissPopOverContentView];

    [self.popOverController presentPopoverFromRect:CGRectMake(30, 1, 1, 20) inView:view
                          permittedArrowDirections:UIPopoverArrowDirectionAny
                                          animated:YES];
    [self.popOverController setPopoverContentSize:CGSizeMake(400, 500)];
}


- (void)didSelectData:(id)data{
    
    if ([selectedView isKindOfClass:[UIButton class]]) {
        UIButton *btn = (UIButton*)selectedView;
        if ([data isKindOfClass:[NSDate class]]) {
            [btn setTitle:[DateTimeHelper convertDate:data toStringWithFormat:dd_MM_YYYY] forState:UIControlStateNormal];
        }else{
            [btn setTitle:data forState:UIControlStateNormal];
        }
    }
    
    [self dismissPopOverContentView];
}

- (void)dismissPopOverContentView{
    if (self.popOverController.isPopoverVisible) {
        [self.popOverController dismissPopoverAnimated:YES];
        self.popOverController = nil;
    }
}



- (IBAction)displayPopOver:(id)sender{
    [self displayPopOverinView:sender withData:nil];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 10;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        
        [tableView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        // cell = [[TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.storageArea.text = @"Freezer";
    cell.counted.text = @"0";
    cell.notCounted.text = @"20";
    cell.status.text = @"In Progress";
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section==0) {
        return self.tableHeader;
    }
    return [[UIView alloc] initWithFrame:CGRectZero];
}




- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 45.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 45.0f;
}

- (UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==0) {
        return self.tableFooter;
    }
    return [[UIView alloc] initWithFrame:CGRectZero];
}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
