//
//  PhysicalInventoryCheckVC.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhysicalInventoryView.h"

@interface PhysicalInventoryCheckVC : UIViewController

@property (nonatomic,strong) IBOutlet PhysicalInventoryView *inventory;

@end
