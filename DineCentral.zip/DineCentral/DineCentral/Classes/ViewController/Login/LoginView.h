//
//  LoginView.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 25/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "ValidationHelper.h"

@interface LoginView : UIView 

@property (nonatomic,strong)   UITextField *userName;
@property (nonatomic,strong)   UITextField *password;
@property (nonatomic,weak) IBOutlet UITableView *login;
@property (nonatomic,weak) UIViewController *parentViewController;

- (IBAction)doLogin:(id)sender;

@end
