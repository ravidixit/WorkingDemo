//
//  LoginVC.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 25/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginView.h"



@interface LoginVC : UIViewController
{
    
}

@property (nonatomic,weak) IBOutlet LoginView *login;


@end
