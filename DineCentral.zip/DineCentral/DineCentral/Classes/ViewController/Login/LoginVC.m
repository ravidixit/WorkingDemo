//
//  LoginVC.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 25/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "LoginVC.h"

@interface LoginVC ()

@end

@implementation LoginVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationController.navigationBarHidden = YES;
    self.login.parentViewController = self;
    [self.login setFrame:CGRectMake(130, 350, 540, 316)];
    [self.view addSubview:self.login];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
