//
//  LoginView.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 25/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "LoginView.h"
#import "PhysicalInventoryCheckVC.h"

@interface LoginView ()
- (BOOL)validateUserDataBeforeLogin;
- (void)navigateToPITCH;
@end


@implementation LoginView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (BOOL)validateUserDataBeforeLogin{
    [ValidationHelper validateEmail:@"test"];
    return NO;
}

- (void)navigateToPITCH{
    PhysicalInventoryCheckVC *pitchVC = [[PhysicalInventoryCheckVC alloc]init];
    [self.parentViewController.navigationController pushViewController:pitchVC animated:YES];
}

- (IBAction)doLogin:(id)sender{
    
    // validate the user and call the login service
    [self navigateToPITCH];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.row==0) {
        self.userName = [[UITextField alloc]init];
        self.userName.keyboardType = UIKeyboardTypeEmailAddress;
        self.userName.borderStyle = UITextBorderStyleNone;
        self.userName.placeholder = @"Email";
        [cell.contentView addSubview:self.userName];
    }else if(indexPath.row==1){
        self.password = [[UITextField alloc]init];
        
        self.password.secureTextEntry = YES;
        self.password.borderStyle = UITextBorderStyleNone;
        self.password.placeholder= @"Password";
        [cell.contentView addSubview:self.password];
    }
    
    NSString *version = [[UIDevice currentDevice] systemVersion];
    int ver = [version intValue];
    if (ver < 7){
        //iOS 6 work
        [self.userName setFrame:CGRectMake(10, 20, 490, 40)];
        [self.password setFrame:CGRectMake(10, 20, 490, 44)];
    }
    else{
        //iOS 7 related work
        [self.userName setFrame:CGRectMake(10, 12, 490, 40)];
        [self.password setFrame:CGRectMake(10, 12, 490, 44)];
    }
    
    return cell;
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return [[UIView alloc] initWithFrame:CGRectZero];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return [[UIView alloc] initWithFrame:CGRectZero];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return @"";
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    self.login.contentInset = UIEdgeInsetsMake(-20, 0, -20, 0);
    for(id object in self.subviews){
        if([object isKindOfClass:[UIButton class]]){
            UIButton *button = (UIButton*)object;
            [button setBackgroundColor:[UIColor colorWithRed:(94/255.0) green:(201/255.0)  blue:(1/255.0)  alpha:1]];
            button.layer.cornerRadius = 12.0f;
        }
    }
    
    self.login.layer.cornerRadius = 10.0f;
    self.clipsToBounds = YES;
    
}


@end
