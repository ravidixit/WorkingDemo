//
//  DateTimeHelper.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MM_DD_YYYY @"MM-dd-YYYY"
#define dd_MM_YYYY @"dd-MM-YYYY"
#define YYYY_MM_DD @"YYYY-MM-dd"

@interface DateTimeHelper : NSObject

+ (NSString*)convertDate:(NSDate*)date toStringWithFormat:(NSString*)dateFormat;

@end
