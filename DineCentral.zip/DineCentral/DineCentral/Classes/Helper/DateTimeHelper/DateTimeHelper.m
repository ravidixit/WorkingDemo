//
//  DateTimeHelper.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "DateTimeHelper.h"

@implementation DateTimeHelper

+ (NSString*)convertDate:(NSDate*)date toStringWithFormat:(NSString*)dateFormat {
    
    if (date!=nil && dateFormat!=nil) {
        NSDateFormatter *df = [[NSDateFormatter alloc]init];
        [df setDateFormat:dateFormat];
        return [df stringFromDate:date];
        df = nil;
    }
    return nil;
}

@end
