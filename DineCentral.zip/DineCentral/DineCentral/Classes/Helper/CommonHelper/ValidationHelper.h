//
//  ValidationHelper.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 25/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ValidationHelper : NSObject

+ (BOOL)validateEmail:(NSString*)email;

@end
