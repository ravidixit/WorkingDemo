//
//  ValidationHelper.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 25/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "ValidationHelper.h"

@implementation ValidationHelper

+ (BOOL)validateEmail:(NSString*)email{
    if (email!=nil) {
    
    }
    return NO;
}

@end
