//
//  Inventory.m
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import "Inventory.h"

@implementation Inventory

@end
