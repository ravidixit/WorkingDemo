//
//  Inventory.h
//  DineCentral
//
//  Created by FLPUNPDSMAC on 28/07/14.
//  Copyright (c) 2014 FLPUNPDSMAC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Inventory : NSObject

@property (nonatomic,weak) NSString *counted;
@property (nonatomic,weak) NSString *notCounted;
@property (nonatomic,weak) NSString *storageArea;
@property (nonatomic,weak) NSString *status;


@end
